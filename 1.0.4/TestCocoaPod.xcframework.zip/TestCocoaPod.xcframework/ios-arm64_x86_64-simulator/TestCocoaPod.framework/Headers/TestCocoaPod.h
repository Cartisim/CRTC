//
//  TestCocoaPod.h
//  TestCocoaPod
//
//  Created by Cole M on 11/15/21.
//

#import <Foundation/Foundation.h>

//! Project version number for TestCocoaPod.
FOUNDATION_EXPORT double TestCocoaPodVersionNumber;

//! Project version string for TestCocoaPod.
FOUNDATION_EXPORT const unsigned char TestCocoaPodVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestCocoaPod/PublicHeader.h>


